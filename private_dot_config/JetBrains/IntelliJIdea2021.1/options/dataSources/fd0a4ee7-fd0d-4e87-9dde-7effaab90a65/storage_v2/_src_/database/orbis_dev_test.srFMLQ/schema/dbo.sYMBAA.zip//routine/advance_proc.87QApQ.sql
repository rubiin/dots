
		CREATE PROCEDURE advance_proc @idx varchar(100), @start_date varchar(100),@end_date varchar(100),@monthly_Salary float(10)
		AS
		BEGIN
		select count(*) as total_transactions,ISNULL(sum(amount),0) as total_advanced , ISNULL((count(*) /NULLIF(count(distinct(employee_id)),0)),0)  as average , ISNULL((sum(amount)/@monthly_Salary),0) as average_advance from "dbo".SaApplication where employer_id = @idx and created_on between @start_date and @end_date
		END;
		
go

