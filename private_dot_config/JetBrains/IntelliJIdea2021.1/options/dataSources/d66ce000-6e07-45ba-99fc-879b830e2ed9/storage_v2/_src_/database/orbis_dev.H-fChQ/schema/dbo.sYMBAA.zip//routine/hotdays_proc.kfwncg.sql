CREATE PROCEDURE hotdays_proc @idx varchar(100), @start_date varchar(100),@end_date varchar(100)
AS
BEGIN
    select count(*) as count, cast(created_on as date) as date from "dbo".SaApplication  where employer_id = @idx  and created_on between @start_date and @end_date group by cast(created_on as date)
END;
go

