CREATE PROCEDURE allowed_routes @idx varchar(100)
		AS
		BEGIN
		SELECT p.idx, p.base_name, p.url, p.method, p.alias, pr.permission_id FROM "dbo".Permission AS p JOIN  "dbo".PermissionUserType AS pr ON p.id = pr.permission_id
		JOIN  "dbo".UserType AS r ON r.id = pr.user_type where r.idx = @idx
		END;
go

