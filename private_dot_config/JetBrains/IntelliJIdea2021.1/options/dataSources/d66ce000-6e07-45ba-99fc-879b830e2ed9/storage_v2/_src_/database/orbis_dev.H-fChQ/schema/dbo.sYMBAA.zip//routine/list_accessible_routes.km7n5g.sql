CREATE PROCEDURE list_accessible_routes @idx varchar(100)
AS
BEGIN
    SELECT  p.alias FROM "dbo".Permission AS p JOIN "dbo".PermissionUserType AS pr ON p.id = pr.permission_id
                                               JOIN "dbo".UserType AS u ON u.id = pr.user_type where u.idx = @idx
END;
go

