
		CREATE PROCEDURE usage_report @idx varchar(100)
		AS
		BEGIN
    select(select count(distinct(id))  from Customer  where employer_id = @idx) as total_employees,
          (select count(distinct(id)) from Customer where is_invited = 0 and is_registered = 0  and employer_id = @idx) as not_invited,
          (select count(distinct(id))  from Customer where is_invited = 0 and is_registered= 1 and sa_approved= 0 and sa_status='PENDING' and employer_id = @idx) as not_approved,
          (select count(distinct(id))  from Customer where is_invited = 1 and is_registered= 0 and sa_approved= 1 and sa_status='ACTIVE' and employer_id = @idx) as approved,
          (select count(distinct(id))  from Customer where is_registered = 1 and is_invited = 1 and sa_approved = 1 and sa_status = 'ACTIVE' and employer_id = @idx) as active,
          (select count(distinct(id))  from Customer where sa_approved = 0 and sa_status ='PENDING'  and employer_id = @idx) as requested;
		END;
		
go

